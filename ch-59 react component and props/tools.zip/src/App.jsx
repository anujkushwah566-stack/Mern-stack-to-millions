import React from 'react'
import { DangerButton, DarkButton, InfoButton, PrimaryButton, SecondaryButton, SuccessButton, WarningButton } from './components/shared/Button'

const App = () => {
  return (
    <div className='p-16 space-x-8'>
      <PrimaryButton onMouseOver={()=>alert()} name="saurav">Register now</PrimaryButton>
      <SecondaryButton>Contact us</SecondaryButton>
      <DangerButton>Signin</DangerButton>
      <WarningButton>Hurry up!</WarningButton>
      <DarkButton>Enroll now</DarkButton>
      <SuccessButton>Limited seats</SuccessButton>
      <InfoButton>Hi user !</InfoButton>
    </div>
  )
}

export default App