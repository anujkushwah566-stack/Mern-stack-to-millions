const Login = ()=>{
    return (
        <div>
            <h1>Login</h1>
            <i className="fa fa-user"></i>
        </div>
    )
}

export default Login