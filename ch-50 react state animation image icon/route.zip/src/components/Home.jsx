import {useState} from 'react'

const Home = () => {
    const [show, setShow] = useState(true)
    return (
        <div>
            Home
            {
                show &&
                <img src="/images/saurav.webp" width="240" />
            }
            <button onClick={()=>setShow(!show)}>Toggle</button>
        </div>
    )
}

export default Home