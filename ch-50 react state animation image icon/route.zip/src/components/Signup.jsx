const Signup = ()=>{
    return (
        <div>
            <h1>Signup</h1>
            <i className="fa fa-gear"></i>
        </div>
    )
}

export default Signup