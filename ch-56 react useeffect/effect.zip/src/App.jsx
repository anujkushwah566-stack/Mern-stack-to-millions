import React, {useState, useEffect} from 'react'
import 'animate.css';
import 'remixicon/fonts/remixicon.css'

const App = () => {
  const [open, setOpen] = useState(false)
  const [openDialog, setOpenDialog] = useState(false)

  useEffect(()=>{
    setTimeout(()=>{
      setOpen(true)
    }, 5000)
  }, [])

  useEffect(()=>{
    setTimeout(()=>{
      setOpenDialog(true)
    }, 10000)
  }, [])

  return (
    <div className='w-8/12 mx-auto py-16 space-y-8'>
      {
        open &&
        <div className='flex justify-between text-lg bg-green-400 py-3 px-4 rounded shadow animate__animated animate__pulse'>
          <div className='flex gap-2'>
            <strong>Success !</strong>
            your create operation is successfully performed
          </div>
          <button className='text-white' onClick={()=>setOpen(false)}>
            <i className="ri-close-circle-fill"></i>
          </button>
        </div>
      }
      <button onClick={()=>setOpen(!open)} className='bg-violet-600 text-white px-8 py-2 rounded font-medium'>Toggle Message</button>
      <button onClick={()=>setOpenDialog(true)} className='ml-4 bg-rose-600 text-white px-8 py-2 rounded font-medium'>Open Dialog</button>
      {
        openDialog &&
        <div className='animate__faster animate__animated animate__fadeIn fixed w-full h-full bg-zinc-900 top-0 left-0'>
          <div className='bg-white animate__animated animate__bounceIn space-y-4 w-6/12 border border-gray-200 p-8 shadow-xl rounded-xl fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2'>
            <h1 className='text-xl font-semibold'>Privacy Policy</h1>
            <p className='text-gray-600'>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Hic earum illum dicta? Enim laboriosam sunt facilis omnis. Quasi asperiores, nisi cum, possimus, magnam praesentium unde odit cumque mollitia non exercitationem.
            </p>
            <button className='absolute top-3 right-3' onClick={()=>setOpenDialog(false)}>
              <i className="ri-close-circle-fill"></i>
            </button>
          </div>
        </div>
      }
    </div>
  )
}

export default App