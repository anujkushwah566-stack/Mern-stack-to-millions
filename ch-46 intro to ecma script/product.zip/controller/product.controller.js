export const createProduct = ()=>{
    console.log("hello")
}

export const fetchProduct = ()=>{
    console.log("hello")
}
