const products = [
    {
      id: 'p1',
      name: 'Wireless Headphones',
      price: 2999,
      category: 'Electronics',
      thumbnail: 'https://example.com/images/headphones.jpg',
      inStock: true,
    },
    {
      id: 'p2',
      name: 'Running Shoes',
      price: 4999,
      category: 'Footwear',
      thumbnail: 'https://example.com/images/shoes.jpg',
      inStock: true,
    },
    {
      id: 'p3',
      name: 'Smartwatch',
      price: 7999,
      category: 'Wearables',
      thumbnail: 'https://example.com/images/smartwatch.jpg',
      inStock: false,
    },
    {
      id: 'p4',
      name: 'Office Chair',
      price: 6499,
      category: 'Furniture',
      thumbnail: 'https://example.com/images/chair.jpg',
      inStock: true,
    },
    {
      id: 'p5',
      name: 'Gaming Keyboard',
      price: 2299,
      category: 'Accessories',
      thumbnail: 'https://example.com/images/keyboard.jpg',
      inStock: true,
    }
]

const x = products.map((item)=>{
    return {
        ...item,
        name: item.name.toUpperCase(),
        rating: 4
    }
})

console.log(x)