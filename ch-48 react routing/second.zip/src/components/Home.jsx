import { Link } from "react-router-dom"

const Home = ()=>{
    return (
        <div>
            <h1 className="text-4xl font-bold text-blue-600">Welcome to home</h1>
            <div>
                <Link to="/">Home</Link>
                <Link to="/pricing">Pricing</Link>
                <Link to="/login">Login</Link>
            </div>
        </div>
    )
}

export default Home