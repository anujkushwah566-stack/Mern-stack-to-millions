const ContactUs = ()=>{
    return (
        <div>
            <h1>Hello welcome to contact</h1>
        </div>
    )
}

export default ContactUs