function myCode() {
    return new Promise((resolve, reject)=>{
        if(12 === 12)
        {
            resolve("My code is success")
        }
        else {
            reject("My code is failed")
        }
    })
}

console.log("one")
const x = myCode()

x.then((msg)=>{
    console.log(msg)
})

.catch((err)=>{
    console.log(err)
})

console.log("three")