import React from 'react'

const App = () => {
  const data = [
    {
      "id": "p001",
      "name": "Wireless Mouse",
      "description": "Ergonomic wireless mouse with USB receiver",
      "price": 19.99,
      "currency": "USD",
      "category": "Electronics",
      "brand": "LogiTech",
      "stock": 150,
      "rating": 4.5,
      "thumbnail": "https://example.com/images/mouse.jpg"
    },
    {
      "id": "p002",
      "name": "Bluetooth Headphones",
      "description": "Noise-cancelling over-ear headphones",
      "price": 59.99,
      "currency": "USD",
      "category": "Audio",
      "brand": "SoundCore",
      "stock": 80,
      "rating": 4.7,
      "thumbnail": "https://example.com/images/headphones.jpg"
    },
    {
      "id": "p003",
      "name": "Smart LED TV 43\"",
      "description": "43-inch 4K UHD Smart LED TV with streaming support",
      "price": 299.99,
      "currency": "USD",
      "category": "Electronics",
      "brand": "Samsung",
      "stock": 45,
      "rating": 4.6,
      "thumbnail": "https://example.com/images/tv.jpg"
    },
    {
      "id": "p004",
      "name": "Men's Running Shoes",
      "description": "Breathable lightweight running shoes for men",
      "price": 49.99,
      "currency": "USD",
      "category": "Footwear",
      "brand": "Nike",
      "stock": 120,
      "rating": 4.3,
      "thumbnail": "https://example.com/images/shoes.jpg"
    },
    {
      "id": "p005",
      "name": "Women's Leather Handbag",
      "description": "Stylish leather handbag with adjustable strap",
      "price": 89.99,
      "currency": "USD",
      "category": "Fashion",
      "brand": "Fossil",
      "stock": 60,
      "rating": 4.8,
      "thumbnail": "https://example.com/images/handbag.jpg"
    },
    {
      "id": "p006",
      "name": "Electric Kettle 1.7L",
      "description": "Fast-boil electric kettle with auto shut-off",
      "price": 24.99,
      "currency": "USD",
      "category": "Home Appliances",
      "brand": "Philips",
      "stock": 90,
      "rating": 4.4,
      "thumbnail": "https://example.com/images/kettle.jpg"
    },
    {
      "id": "p007",
      "name": "Gaming Keyboard RGB",
      "description": "Mechanical keyboard with customizable RGB lights",
      "price": 39.99,
      "currency": "USD",
      "category": "Gaming",
      "brand": "Redragon",
      "stock": 75,
      "rating": 4.6,
      "thumbnail": "https://example.com/images/keyboard.jpg"
    },
    {
      "id": "p008",
      "name": "Smartphone 128GB",
      "description": "5G enabled smartphone with 128GB storage and triple camera",
      "price": 499.99,
      "currency": "USD",
      "category": "Mobiles",
      "brand": "OnePlus",
      "stock": 40,
      "rating": 4.7,
      "thumbnail": "https://example.com/images/phone.jpg"
    },
    {
      "id": "p009",
      "name": "Fitness Tracker Watch",
      "description": "Water-resistant fitness band with heart rate monitor",
      "price": 34.99,
      "currency": "USD",
      "category": "Wearables",
      "brand": "Fitbit",
      "stock": 100,
      "rating": 4.5,
      "thumbnail": "https://example.com/images/fitbit.jpg"
    },
    {
      "id": "p010",
      "name": "Ceramic Dinner Set",
      "description": "16-piece ceramic dinner set - microwave safe",
      "price": 69.99,
      "currency": "USD",
      "category": "Kitchen",
      "brand": "Corelle",
      "stock": 55,
      "rating": 4.6,
      "thumbnail": "https://example.com/images/dinnerware.jpg"
    }
  ]
  
  return (
    <div className='grid grid-cols-4 gap-8 w-10/12 mx-auto py-16'>
      {
        data.map((item, index)=>(
          <div key={index} className='bg-white border border-gray-300 rounded-lg p-8 space-y-3'>
            <h1 className='text-xl font-semibold'>{item.name}</h1>
            <div className='bg-green-500 text-white rounded px-2 py-2 w-fit'>{item.brand}</div>
            <h1>₹{item.price}</h1>
          </div>
        ))
      }
    </div>
  )
}

export default App