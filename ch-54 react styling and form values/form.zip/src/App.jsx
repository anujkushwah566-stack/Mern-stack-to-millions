import React, { useState } from 'react'

const App = () => {
  const [loginForm, setLoginForm] = useState({
    email: '',
    password: '',
    fullname: ''
  })

  const handleLoginForm = (e)=>{
    const input = e.target
    const name = input.name
    const value = input.value
    setLoginForm({
      ...loginForm,
      [name]: value
    })
  }


  const inputDesign = {
    border: '1px solid #ccc', 
    padding: 16, 
    borderRadius: 8
  }

  return (
    <div style={{
      width: '60%',
      background: '#ddd',
      borderRadius: 24,
      padding: 24
    }}>
      <form style={{
        display: 'flex',
        flexDirection: 'column',
        gap: 16
      }}>
        <input 
          style={inputDesign}
          placeholder='email' 
          name="email" 
          onChange={handleLoginForm} 
        />

        <input 
          style={inputDesign}
          placeholder='password' 
          name="password" 
          onChange={handleLoginForm} 
        />

        <input 
          style={inputDesign}
          placeholder='fullname' 
          name="fullname" 
          onChange={handleLoginForm} 
        />

        <button style={{
          border: 'none',
          padding: 16,
          borderRadius: 8,
          background: 'dodgerblue',
          color: 'white',
          fontWeight: 'bold',
          fontSize: 17
        }}>login</button>
      </form>
    </div>
  )
}

export default App