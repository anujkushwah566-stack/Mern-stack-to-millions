const App = ()=>{
    return (
        <div style={{
            width: 200,
            height: 200,
            backgroundColor: "red",
            borderRadius: 20
        }}>
           <p style={{
            fontSize: 100,
            fontWeight: "bold",
            color: "white",
            fontFamily: "sans-serif"
           }}>Hello Sir</p> 
        </div>
    )
}

export default App